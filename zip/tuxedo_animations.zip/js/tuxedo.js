$(document).ready(function() {

  //=================Animation functionality=============//
  function animations() {
    $(window).scroll( function(){  /* Every time the window is scrolled ... */

      /* Check the location of each animate-in elements */
      $('.animate-in').each( function(){
        var objectBottom = $(this).offset().top + $(this).outerHeight();
        var windowBottom = $(window).scrollTop() + $(window).height();

        /* If the object is completely visible in the window, fade it it */
        if (objectBottom < windowBottom) { //object comes into view (scrolling down)
          if ($(this).css("opacity")==0) {$(this).fadeTo(500,1);}
        } else { //object goes out of view (scrolling up) fade out
          if ($(this).css("opacity")==1) {$(this).fadeTo(500,0);}
        }
      });
    });
  }


////////// Add Functions to Call HERE//////////
  animations();
});
