$(document).ready(function() {

  //=================Mobile menu functionality=============//
function mobileMenu() {
  $('.hamburger').click(function() {
    $('.flyout').show();
    $('body').css({'overflow': 'hidden'});
  });
  $('.close').click(function() {
    $('.flyout').hide();
    $('body').css({'overflow': 'auto'});
  });
  $('.fly-dropdown').click(function() {
    $(this).children('.dropdown-menu').fadeToggle();
  });
  $('.sub-fly-dropdown').hover(function() {
    $(this).children('.sub-dropdown-menu').fadeToggle();
  });
}



////////// Add Functions to Call HERE//////////


mobileMenu();


});
